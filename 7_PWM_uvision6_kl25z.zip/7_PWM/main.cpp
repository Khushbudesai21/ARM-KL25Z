#include "mbed.h"
PwmOut myled(LED1);
PwmOut myled2(LED2);
int main() {
    float i;
    while(1) {
        for(i=0;i<1;i+=0.1)
        {
            myled.write(1-i);
            myled2.write(i);
            wait(0.2);
        }
}
}
