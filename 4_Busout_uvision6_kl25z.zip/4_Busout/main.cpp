#include "mbed.h"

BusOut rgbled(PTD1,PTB19,PTB18);

int main() {
    while(1) {
     
      rgbled = 0b0011;
      wait(0.5);
     
      rgbled = 0b0001;
      wait(0.5);
    
      rgbled = 0b0101;
      wait(0.5);
     
      rgbled = 0b0001;
      wait(0.5);
      
       rgbled = 0b0110;
      wait(0.5);
     
      rgbled = 0b0010;
      wait(0.5);
      
      
    }
}
