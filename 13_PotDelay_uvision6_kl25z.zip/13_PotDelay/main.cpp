#include "mbed.h"

PwmOut l(LED1);
AnalogIn pot(PTB0);

int main()
{
    float potval;
    while(1)
    {
        potval=pot.read();
        l.write(0);
        wait(potval);
        l.write(1);
        wait(potval);
        
        
        
    }
}    
