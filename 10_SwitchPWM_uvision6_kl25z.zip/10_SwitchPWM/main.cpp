#include "mbed.h"

PwmOut l1(LED1);
PwmOut l2(LED2);
PwmOut l3(LED3);
DigitalIn s(PTC9);
int i=0;
float j;

int main() {
    while(1) {
        if(s.read()==0){
                i=i+1;
                }
                
        l1=1;
        l2=1;
        l3=1;
       
       if(i%3==0){
           for(j=0;j<1;j=j+0.1)
           {l1.write(j);
           wait(0.2);}
           wait(0.3);
           for(j=0;j<1;j=j+0.1)
           {l1.write(1-j);
           wait(0.2);}
           wait(0.3);
           l1=1;
          
        }
        
        if(i%3==1){
           for(j=0;j<1;j=j+0.1)
           {l2.write(j);
           wait(0.2);}
           wait(0.3);
           for(j=0;j<1;j=j+0.1)
           {l2.write(1-j);
           wait(0.2);}
           wait(0.3);
           l2=1;
          
        }
        
        if(i%3==2){
           for(j=0;j<1;j=j+0.1)
           {l3.write(j);
           wait(0.2);}
           wait(0.3);
           for(j=0;j<1;j=j+0.1)
           {l3.write(1-j);
           wait(0.2);}
           wait(0.3);
           l3=1;
           
        }
        
          
  }
  }        
