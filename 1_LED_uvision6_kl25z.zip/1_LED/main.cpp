#include "mbed.h"

DigitalOut myled(LED3);

int main() {
int k=1;
    while(k<10) {
        myled = 1;
        wait(0.2);
        myled = 0;
        wait(0.2);
        k++;
        
        }
    myled=1;
}
