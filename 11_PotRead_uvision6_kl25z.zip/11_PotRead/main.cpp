#include "mbed.h"

AnalogIn pot(PTB0);
BusOut led(PTB18,PTB19,PTD1);

int main(){
    float potval;
    while(1){
        potval=pot.read();
        if(potval<=0.33){
            led=0b0110;
            }
        
        else if(potval<=0.66){
            led=0b0101;
            }
            
        else{
            led=0b0011;
            }
            
 
}
} 