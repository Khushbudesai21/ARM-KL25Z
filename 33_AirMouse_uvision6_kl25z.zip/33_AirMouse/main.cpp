#include "mbed.h"
#include "MMA8451Q.h"
#include "USBMouse.h"
#include "TSISensor.h"
TSISensor tsi;

USBMouse mouse;

MMA8451Q acc(PTE25,PTE24,0x1d<<1);

int main()
{
    float x,y,t;
    
    while(1)
    { x=acc.getAccX()*10;
      y=acc.getAccY()*10;
      mouse.move(-y,-x);
      t=tsi.readPercentage();
      
    if(t>0.6)
    {
        mouse.press(MOUSE_LEFT);
        }
        else if(t<0.4 && t!=0)
        {
            mouse.press(MOUSE_RIGHT);
        }
        else{
            mouse.press(MOUSE_LEFT);
            mouse.release(MOUSE_RIGHT);
            }
            wait(0.1);
            }
            }