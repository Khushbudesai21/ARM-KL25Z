
#include "MMA8451Q.h"
#define MMA8451_I2C_ADDRESS (0x1d<<1)
/*#include "mbed.h"

 MMA8451Q acc(PTE25,PTE24,MMA8451_I2C_ADDRESS);
 Serial pc (USBTX,USBRX);
 int main()
 {
     float accx,accy,accz;
     while(1){
         accx=acc.getAccX();
         accy=acc.getAccY();
         accz=acc.getAccZ();
         pc.baud(115200);
         pc.printf("$X:%f \n Y: %f \n Z:%f \n\r",accx,accy,accz);
         wait(2.0);
 
    }
}
*/

#include "mbed.h"

 MMA8451Q acc(PTE25,PTE24,MMA8451_I2C_ADDRESS);
 Serial pc (USBTX,USBRX);
 int main()
 {
     int accx,accy,accz;
     int range =1000;
     pc.baud(115200);
     while(1){
         accx=(acc.getAccX()+1)*range;
         accy=(acc.getAccY()+1)*range;
         accz=(acc.getAccZ()+1)*range;
         
         pc.printf("$X:%d \n Y: %d \n Z:%d \n\r",accx,accy,accz);
         wait(0.1);
         }
         }
