#include "mbed.h"

PwmOut led(PTB18);
Serial pc(USBTX,USBRX);

int main() {
    char ch;
    led=1;
    while(1){
        ch=pc.getc();
        switch(ch)
        {
            case '1':led.write(0.1);break;
            case '2':led.write(0.2);break;
            case '3':led.write(0.3);break;
            case '4':led.write(0.4);break;
            case '5':led.write(0.5);;break;
            case '6':led.write(0.6);break;
            case '7':led.write(0.7);break;
            case '8':led.write(0.8); break;
            case '9':led.write(0.9);break;
            default: led.write(1);break;
                     
        }
    }
}
