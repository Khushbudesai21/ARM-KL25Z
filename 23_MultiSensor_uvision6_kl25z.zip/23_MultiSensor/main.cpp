#include "mbed.h"

AnalogIn pot(PTB0);
AnalogIn ldr(PTB1);
Serial pc(USBTX,USBRX);

int main()
{
    float i;
    float j;
    while(1){
        i=ldr.read();
        j=pot.read();
        pc.printf("LDR value is %0.2f and Potvalue is %0.2f \n\r",i,j);
        wait(0.1);
        }
        }
        