#include "mbed.h"

PwmOut led(LED1);

int main()
{
    int i=1;
    if(i>=1)
    {
    led.period(4.0f);
    led.write(0.5f);
    i--;
    }
    while(1);
    }