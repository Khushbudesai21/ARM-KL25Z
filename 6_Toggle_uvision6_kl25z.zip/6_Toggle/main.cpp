#include "mbed.h"

DigitalOut l(LED1);
DigitalIn s(PTC9);
int i;
int main() {
    while(1) {
        if(s==1){
            wait(0.1);
        if (s==0)
        { 
            i=i+1;
        }
        }
        if(i%2==0)
        {
        l=1;}
        else
        {
        l=0;
    }
}}
