#include "mbed.h"
PwmOut myled(LED1);
PwmOut myled2(LED2);
PwmOut myled3(LED3);
int main() {
    float i;
    while(1) {
        for(i=0;i<=1;i+=0.1)
        {
            myled3.write(1-i);
            myled.write(i);
            wait(0.5);
        }
        
        for(i=0;i<=1;i+=0.1)
        {
            myled.write(1-i);
            myled2.write(i);
            wait(0.5);
        }
        for(i=0;i<=1;i+=0.1)
        {
            myled2.write(1-i);
            myled3.write(i);
            wait(0.5);
        }
}
}
