#include "mbed.h"

DigitalOut myled(LED1);
DigitalIn myswitch(PTC9);

int main() {
    while(1) {
        myled.write(1);
        while(myswitch.read()==0)
        {
         myled.write(0);
    }
    }
}
