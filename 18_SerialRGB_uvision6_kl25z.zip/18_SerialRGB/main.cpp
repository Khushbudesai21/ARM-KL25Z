#include "mbed.h"

BusOut led(PTB18,PTB19,PTD1);
Serial pc(USBTX,USBRX);

int main() {
    char ch;
    led=0b0111;
    while(1){
        ch=pc.getc();
        switch(ch)
        {
            case 'R':led=0b0111;break;
            case 'r':led=0b0110;
                     break;
            case 'G':led=0b0111;break;
            case 'g':led=0b0101;
                     break;
            case 'B':led=0b0111;break;
            case 'b':led=0b0011;
                     break;
                     
        }
    }
}
